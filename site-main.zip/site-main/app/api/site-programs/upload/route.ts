import { NextRequest, NextResponse } from "next/server";
import { revalidateTag } from "next/cache";
import {
  SITE_BASE_ID,
  parseRecord,
  siteBaseUrl,
  siteAuthHeaders,
} from "../../../../lib/site-programs";
import { canEditProgram } from "../../../../lib/server-auth";
import { apiError } from "@/lib/api-error";
import { PROGRAMS_CACHE_TAG, fetchAllPages } from "@/lib/programs-data";

export const dynamic = "force-dynamic";

function apiKey() {
  return process.env.HACK_CLUB_SITE_AIRTABLE_KEY;
}

const ALLOWED_MIME: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/gif": "gif",
  "image/webp": "webp",
};

async function compressToWebp(
  input: Buffer,
): Promise<{ buffer: Buffer; mime: string; ext: string } | null> {
  const tinifyKey = process.env.TINIFY_API_KEY;
  if (!tinifyKey) {
    console.error("[upload] TINIFY_API_KEY is not set — uploading original bytes");
    return null;
  }
  const auth = `Basic ${Buffer.from(`api:${tinifyKey}`).toString("base64")}`;

  try {
    const shrinkRes = await fetch("https://api.tinify.com/shrink", {
      method: "POST",
      headers: { Authorization: auth },
      body: new Uint8Array(input),
      signal: AbortSignal.timeout(15_000),
    });
    if (!shrinkRes.ok) {
      console.error("[upload] Tinify shrink failed", shrinkRes.status, await shrinkRes.text());
      return null;
    }
    const location = shrinkRes.headers.get("location");
    if (!location) {
      console.error("[upload] Tinify shrink returned no Location header");
      return null;
    }

    const convertRes = await fetch(location, {
      method: "POST",
      headers: { Authorization: auth, "Content-Type": "application/json" },
      body: JSON.stringify({ convert: { type: ["image/webp"] } }),
      signal: AbortSignal.timeout(15_000),
    });
    if (!convertRes.ok) {
      console.error("[upload] Tinify convert failed", convertRes.status, await convertRes.text());
      return null;
    }

    const outMime = (convertRes.headers.get("content-type") ?? "").split(";")[0].trim();
    const outExt = ALLOWED_MIME[outMime];
    if (!outExt) {
      console.error("[upload] Tinify returned unexpected content type", outMime);
      return null;
    }

    const buffer = Buffer.from(await convertRes.arrayBuffer());
    if (buffer.byteLength >= input.byteLength) {
      console.error(
        "[upload] Tinify output was not smaller — uploading original bytes",
        `${input.byteLength} -> ${buffer.byteLength}`,
      );
      return null;
    }
    return { buffer, mime: outMime, ext: outExt };
  } catch (e) {
    console.error("[upload] Tinify compression failed", e);
    return null;
  }
}

/**
 * Find or create a record by program name.
 *
 * The lookup walks every page: Airtable stops a list response at 100 records,
 * and a truncated one that happens to omit `programName` sends this straight to
 * the create branch, duplicating a program that already has a record. A failed
 * list must throw rather than read as an empty table, for the same reason.
 */
async function findOrCreate(programName: string, key: string): Promise<string> {
  const records = (await fetchAllPages(`${siteBaseUrl()}?fields[]=Name`, siteAuthHeaders(key))) as {
    id: string;
    fields: { Name?: string };
  }[];
  const existing = records.find((r) => r.fields.Name === programName);
  if (existing) return existing.id;

  const createRes = await fetch(siteBaseUrl(), {
    method: "POST",
    headers: siteAuthHeaders(key),
    body: JSON.stringify({ records: [{ fields: { Name: programName } }] }),
  });
  const createData = await createRes.json();
  const created = createData.records?.[0] as { id: string } | undefined;
  if (!created) throw new Error("Failed to create record");
  return created.id;
}

// POST — upload logo or background image for a program
// FormData fields: programName (string), type ("logo" | "bg"), file (File)
export async function POST(req: NextRequest) {
  const key = apiKey();
  if (!key) {
    return apiError({
      status: 500,
      code: "server_misconfigured",
      message: "HACK_CLUB_SITE_AIRTABLE_KEY is not set",
    });
  }

  const form = await req.formData();
  const programName = form.get("programName");
  const type = form.get("type");
  const file = form.get("file");

  if (typeof programName !== "string" || !programName.trim() || programName.length > 200) {
    return apiError({
      status: 400,
      code: "bad_request",
      message: "Invalid programName",
      hint: "Send the program's exact name in the `programName` form field (1-200 characters).",
    });
  }
  if (type !== "logo" && type !== "bg") {
    return apiError({
      status: 400,
      code: "bad_request",
      message: "Invalid type (expected 'logo' or 'bg')",
    });
  }
  if (!(file instanceof File)) {
    return apiError({ status: 400, code: "bad_request", message: "Missing file" });
  }

  const mime = file.type;
  const ext = ALLOWED_MIME[mime];
  if (!ext) {
    return apiError({
      status: 415,
      code: "unsupported_media_type",
      message: "Unsupported file type. Allowed: PNG, JPEG, GIF, WebP.",
    });
  }
  if (file.size > 8 * 1024 * 1024) {
    return apiError({
      status: 413,
      code: "payload_too_large",
      message: "File too large (max 8 MB)",
    });
  }

  if (!(await canEditProgram(req, programName))) {
    return apiError({
      status: 403,
      code: "forbidden",
      message: "Forbidden",
      hint: "Sign in at /api/auth/login as an owner of this program, or as an admin.",
    });
  }

  const fieldName = type === "logo" ? "Logo" : "BG Image";

  let recordId: string;
  try {
    recordId = await findOrCreate(programName, key);
  } catch (e) {
    console.error("[upload] record lookup failed", e);
    return apiError({
      status: 502,
      code: "upstream_error",
      message: "Failed to look up program",
    });
  }
  if (!/^rec[A-Za-z0-9]{14}$/.test(recordId)) {
    console.error("[upload] unexpected Airtable record id", recordId);
    return apiError({
      status: 502,
      code: "upstream_error",
      message: "Invalid record id from upstream",
    });
  }

  const original = Buffer.from(await file.arrayBuffer());
  const compressed = mime === "image/gif" ? null : await compressToWebp(original);
  const uploadMime = compressed?.mime ?? mime;
  const filename = `${type}.${compressed?.ext ?? ext}`;
  const base64 = (compressed?.buffer ?? original).toString("base64");

  const uploadRes = await fetch(
    `https://content.airtable.com/v0/${SITE_BASE_ID}/${encodeURIComponent(recordId)}/${encodeURIComponent(fieldName)}/uploadAttachment`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contentType: uploadMime,
        filename,
        file: base64,
      }),
    },
  );

  if (!uploadRes.ok) {
    console.error("[upload] Airtable content API error", uploadRes.status, await uploadRes.text());
    return apiError({
      status: uploadRes.status,
      code: "upstream_error",
      message: `Upload failed (${uploadRes.status})`,
    });
  }

  // Fetch the updated record to return fresh data
  const fetchRes = await fetch(`${siteBaseUrl()}/${encodeURIComponent(recordId)}`, {
    headers: siteAuthHeaders(key),
    cache: "no-store",
  });
  if (!fetchRes.ok) {
    return apiError({
      status: 500,
      code: "upstream_error",
      message: "Upload succeeded but failed to fetch updated record",
    });
  }

  const updatedProgram = parseRecord(await fetchRes.json());
  revalidateTag(PROGRAMS_CACHE_TAG, { expire: 0 });
  return NextResponse.json(updatedProgram);
}
