"use client";

import { useState, useEffect, useRef, useCallback, useMemo, type ReactNode } from "react";
import NextLink from "next/link";
import Image from "next/image";
import { useLocale, useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import type { ProjectType } from "@/lib/site-programs";
import { PROJECT_TYPE_OPTIONS, formatInPersonDate } from "@/lib/site-programs";
import type { Event, EventFormat, EventStatus } from "@/lib/events";
import { hasEventArtwork } from "@/lib/events";
import { parseLocalDate } from "@/lib/programs";
import { BtnArrowSvg } from "@/components/landing/btn-arrow";
import { ProgramCardVisual } from "@/components/programs/ProgramCardVisual";

function useProjectTypeLabel() {
  const t = useTranslations("Programs");
  return (type: ProjectType) => {
    switch (type) {
      case "Electronics":
        return t("projectTypeElectronics");
      case "Websites":
        return t("projectTypeWebsites");
      case "Software":
        return t("projectTypeSoftware");
      case "Gamedev":
        return t("projectTypeGamedev");
      case "CAD":
        return t("projectTypeCAD");
      case "Other":
        return t("projectTypeOther");
      default:
        return type;
    }
  };
}

function useFormatLabel() {
  const t = useTranslations("Programs");
  return (format: EventFormat) => {
    switch (format) {
      case "in-person":
        return t("formatInPersonOnly");
      case "online":
        return t("formatOnlineOnly");
      case "both":
        return t("formatBoth");
      default:
        return format;
    }
  };
}

function ProgramCard({ event }: { event: Event }) {
  const t = useTranslations("Programs");
  const locale = useLocale();
  const projectTypeLabel = useProjectTypeLabel();
  const wrapperRef = useRef<HTMLDivElement>(null);
  // oxlint-disable-next-line react/purity
  const now = useMemo(() => new Date(), []);
  // If no end date, program runs indefinitely (never ends)
  const isEnded = event.endDate ? parseLocalDate(event.endDate) < now : false;
  const isUpcoming =
    parseLocalDate(event.startDate) > now ||
    (event.inPerson?.start ? parseLocalDate(event.inPerson.start) > now : false);

  const theme = event.theme;
  const background = event.background;
  const bgColor = background?.color ?? "var(--surface)";
  const textColor = theme?.text ?? "var(--foreground)";
  const accentColor = theme?.accent ?? "#ec3750";
  const logoUrl = event.logoUrl;
  const logoSize = theme?.logoSize ?? 48;
  const bgImageUrl = background?.type === "image" ? background.imageUrl : null;
  const buttonLabel = isEnded ? t("seeTheSite") : t("startNow");
  const buttonColor = theme?.button.color ?? "#ec3750";
  const buttonTextColor = theme?.button.textColor ?? "#ffffff";
  const buttonRadius = theme?.button.borderRadius ?? 44;
  const buttonBorderWidth = theme?.button.borderWidth ?? 0;
  const buttonBorderColor = theme?.button.borderColor ?? "var(--foreground)";
  const slackChannel = event.slackChannel;
  const slackUrl = event.slackUrl;
  const projectTypes = event.projectTypes;
  const format = event.format;
  const description = event.description;

  const badgeLabel = isUpcoming
    ? t("statusUpcoming")
    : isEnded
      ? t("statusEnded")
      : event.endDate
        ? t("ends", {
            date: parseLocalDate(event.endDate).toLocaleDateString(locale, {
              day: "numeric",
              month: "short",
            }),
          })
        : t("statusOngoing");
  const badgeEnded = isEnded || isUpcoming;

  // Italic metadata lines
  const metaLines: string[] = [];
  const inPersonStr = formatInPersonDate(
    event.inPerson?.start ?? null,
    event.inPerson?.end ?? null,
    event.inPerson?.location ?? null,
    locale,
  );
  if ((format === "in-person" || format === "both") && inPersonStr)
    metaLines.push(t("metaInPerson", { details: inPersonStr }));
  if (format === "online") metaLines.push(t("metaOnlineOnly"));
  if (format === "both" && !inPersonStr) metaLines.push(t("metaInPersonAndOnline"));
  if (projectTypes.length > 0)
    metaLines.push(
      projectTypes.length === PROJECT_TYPE_OPTIONS.length
        ? t("metaProjectTypeAny")
        : t("metaProjectTypes", {
            types: projectTypes.map(projectTypeLabel).join(", "),
          }),
    );
  if (event.requirements) metaLines.push(event.requirements);

  return (
    <div
      ref={wrapperRef}
      onMouseMove={(e) => {
        const el = wrapperRef.current;
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const dx = (e.clientX - rect.left) / rect.width - 0.5;
        const dy = (e.clientY - rect.top) / rect.height - 0.5;
        el.style.transform = `perspective(900px) scale(1.012) rotateY(${dx * 4}deg) rotateX(${-dy * 3}deg)`;
      }}
      onMouseLeave={() => {
        const el = wrapperRef.current;
        if (!el) return;
        el.style.transition = "transform 0.4s ease";
        el.style.transform = "perspective(900px) scale(1) rotateY(0deg) rotateX(0deg)";
        setTimeout(() => {
          if (wrapperRef.current) wrapperRef.current.style.transition = "transform 0.06s ease";
        }, 400);
      }}
      onMouseEnter={() => {
        if (wrapperRef.current) wrapperRef.current.style.transition = "transform 0.06s ease";
      }}
      style={{ position: "relative", transition: "transform 0.06s ease", willChange: "transform" }}
    >
      <ProgramCardVisual
        name={event.name}
        logoUrl={logoUrl}
        logoSize={logoSize}
        bgColor={bgColor}
        bgImageUrl={bgImageUrl}
        textColor={textColor}
        accentColor={accentColor}
        description={description}
        metaLines={metaLines}
        buttonLabel={buttonLabel}
        buttonHref={event.url}
        buttonColor={buttonColor}
        buttonTextColor={buttonTextColor}
        buttonRadius={buttonRadius}
        buttonBorderWidth={buttonBorderWidth}
        buttonBorderColor={buttonBorderColor}
        slackIntro={t("joinDiscussion")}
        slackChannel={slackChannel}
        slackUrl={slackUrl}
        badgeLabel={badgeLabel}
        badgeMuted={badgeEnded}
        pinned={event.pinned}
        interactive
      />
    </div>
  );
}

// ── Loading skeleton ──────────────────────────────────────────────────────────
function CardSkeleton() {
  return (
    <div
      style={{
        borderRadius: 16,
        background: "var(--surface-hover)",
        minHeight: 260,
        animation: "pulse 1.5s ease-in-out infinite",
      }}
    />
  );
}

// ── Chevron icon ──────────────────────────────────────────────────────────────
function Chevron({ color = "currentColor" }: { color?: string }) {
  return (
    <svg width="14" height="8" viewBox="0 0 14 8" fill="none" style={{ flexShrink: 0 }}>
      <path
        d="M1 1l6 6 6-6"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

// ── Generic pill dropdown ─────────────────────────────────────────────────────
function PillDropdown({
  label,
  active,
  onClear,
  children,
}: {
  label: string;
  active: boolean;
  onClear: () => void;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const openRafRef = useRef<number | null>(null);
  const closeTimeoutRef = useRef<number | null>(null);

  const clearTimers = useCallback(() => {
    if (openRafRef.current !== null) {
      cancelAnimationFrame(openRafRef.current);
      openRafRef.current = null;
    }
    if (closeTimeoutRef.current !== null) {
      window.clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
  }, []);

  const openPanel = useCallback(() => {
    clearTimers();
    setOpen(true);
    setMounted(true);
    openRafRef.current = requestAnimationFrame(() => {
      openRafRef.current = requestAnimationFrame(() => {
        setVisible(true);
        openRafRef.current = null;
      });
    });
  }, [clearTimers]);

  const closePanel = useCallback(() => {
    clearTimers();
    setOpen(false);
    setVisible(false);
    closeTimeoutRef.current = window.setTimeout(() => {
      setMounted(false);
      closeTimeoutRef.current = null;
    }, 180);
  }, [clearTimers]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) closePanel();
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => {
      document.removeEventListener("mousedown", onClickOutside);
      clearTimers();
    };
  }, [clearTimers, closePanel]);

  return (
    <div ref={ref} style={{ position: "relative", display: "inline-block" }}>
      <button
        onClick={() => (open ? closePanel() : openPanel())}
        className="filter-pill"
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 8,
          height: 40,
          paddingLeft: active ? 8 : 16,
          paddingRight: 16,
          borderRadius: 9999,
          border: "2.5px solid var(--red)",
          background: "transparent",
          fontFamily: "var(--font-phantom)",
          fontSize: 20,
          color: active ? "var(--red)" : "var(--foreground)",
          cursor: "pointer",
          whiteSpace: "nowrap",
          outline: "none",
        }}
      >
        {active && (
          <span
            onClick={(e) => {
              e.stopPropagation();
              onClear();
            }}
            aria-hidden="true"
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              width: 20,
              height: 20,
              borderRadius: "50%",
              background: "#ec3750",
              cursor: "pointer",
              flexShrink: 0,
            }}
          >
            <svg
              width="10"
              height="10"
              viewBox="0 0 10 10"
              fill="none"
              style={{ display: "block" }}
            >
              <path d="M2 2l6 6M8 2L2 8" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </span>
        )}
        {label}
        <Chevron />
      </button>
      {mounted && (
        <div
          className="filter-panel"
          data-open={visible}
          style={{
            position: "absolute",
            top: "calc(100% + 8px)",
            left: 0,
            background: "var(--surface)",
            border: "3px solid var(--red)",
            borderRadius: 16,
            padding: "12px 16px",
            display: "flex",
            flexDirection: "column",
            gap: 10,
            zIndex: 100,
            minWidth: 220,
            boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
          }}
        >
          {children}
        </div>
      )}
    </div>
  );
}

function CheckItem({
  label,
  checked,
  onToggle,
}: {
  label: string;
  checked: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={checked}
      style={{
        appearance: "none",
        border: "none",
        background: "none",
        padding: 0,
        textAlign: "left",
        display: "flex",
        alignItems: "center",
        gap: 10,
        cursor: "pointer",
        fontFamily: "var(--font-phantom)",
        fontSize: 20,
        color: "var(--foreground)",
        userSelect: "none",
      }}
    >
      <span
        style={{
          width: 20,
          height: 20,
          borderRadius: 6,
          border: "2.5px solid var(--red)",
          background: checked ? "var(--red)" : "transparent",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          transition: "background 150ms ease",
        }}
      >
        {checked && (
          <svg width="12" height="10" viewBox="0 0 12 10" fill="none">
            <path
              d="M1 5l3.5 3.5L11 1"
              stroke="#fff"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </span>
      {label}
    </button>
  );
}

type SortOption = "deadline-asc" | "deadline-desc" | "az" | "za";
const FORMAT_OPTIONS: EventFormat[] = ["in-person", "online", "both"];

// ── Page ──────────────────────────────────────────────────────────────────────
export default function ProgramsPage() {
  const t = useTranslations("Programs");
  const locale = useLocale();
  const projectTypeLabel = useProjectTypeLabel();
  const formatLabelFn = useFormatLabel();
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortOption>("deadline-asc");
  const [statusFilter, setStatusFilter] = useState<Set<EventStatus>>(new Set(["ongoing"]));
  const [formatFilter, setFormatFilter] = useState<Set<EventFormat>>(new Set());
  const [typeFilter, setTypeFilter] = useState<Set<ProjectType>>(new Set());
  const [events, setEvents] = useState<Event[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const sortRef = useRef<HTMLDivElement>(null);
  const [sortOpen, setSortOpen] = useState(false);
  const [sortMounted, setSortMounted] = useState(false);
  const [sortVisible, setSortVisible] = useState(false);
  const magazineBgRef = useRef<HTMLImageElement>(null);
  const sortOpenRafRef = useRef<number | null>(null);
  const sortCloseTimeoutRef = useRef<number | null>(null);

  const STATUS_LABELS: Record<EventStatus, string> = {
    ongoing: t("statusOngoing"),
    ended: t("statusEnded"),
    upcoming: t("statusUpcoming"),
  };

  const SORT_LABELS: Record<SortOption, ReactNode> = {
    "deadline-asc": t("sortEarliest"),
    "deadline-desc": t("sortLatest"),
    az: t("sortAz"),
    za: t("sortZa"),
  };

  const clearSortTimers = useCallback(() => {
    if (sortOpenRafRef.current !== null) {
      cancelAnimationFrame(sortOpenRafRef.current);
      sortOpenRafRef.current = null;
    }
    if (sortCloseTimeoutRef.current !== null) {
      window.clearTimeout(sortCloseTimeoutRef.current);
      sortCloseTimeoutRef.current = null;
    }
  }, []);

  const openSortPanel = useCallback(() => {
    clearSortTimers();
    setSortOpen(true);
    setSortMounted(true);
    sortOpenRafRef.current = requestAnimationFrame(() => {
      sortOpenRafRef.current = requestAnimationFrame(() => {
        setSortVisible(true);
        sortOpenRafRef.current = null;
      });
    });
  }, [clearSortTimers]);

  const closeSortPanel = useCallback(() => {
    clearSortTimers();
    setSortOpen(false);
    setSortVisible(false);
    sortCloseTimeoutRef.current = window.setTimeout(() => {
      setSortMounted(false);
      sortCloseTimeoutRef.current = null;
    }, 180);
  }, [clearSortTimers]);

  const onScroll = useCallback(() => {
    const y = window.scrollY;
    if (magazineBgRef.current)
      magazineBgRef.current.style.transform = `scaleY(-1) translateY(-${y * 0.5}px)`;
  }, []);

  useEffect(() => {
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [onScroll]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (sortRef.current && !sortRef.current.contains(e.target as Node)) closeSortPanel();
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => {
      document.removeEventListener("mousedown", onClickOutside);
      clearSortTimers();
    };
  }, [clearSortTimers, closeSortPanel]);

  useEffect(() => {
    fetch("/api/v1/events")
      .then((r) => r.json())
      .then((json) => {
        if (Array.isArray(json?.data)) setEvents(json.data);
        else setError(json?.message ?? t("errorLoad"));
      })
      .catch(() => setError(t("errorNetwork")));
  }, [t]);

  const filtered = (events ?? []).filter((p) => {
    if (!hasEventArtwork(p)) return false;
    const q = search.toLowerCase();
    const matchesSearch =
      !q ||
      p.name.toLowerCase().includes(q) ||
      (p.description ?? "").toLowerCase().includes(q) ||
      (p.inPerson?.location ?? "").toLowerCase().includes(q);
    if (!matchesSearch) return false;
    if (statusFilter.size > 0 && !statusFilter.has(p.status)) return false;
    if (formatFilter.size > 0) {
      if (!p.format || !formatFilter.has(p.format)) return false;
    }
    if (typeFilter.size > 0) {
      if (![...typeFilter].some((type) => p.projectTypes.includes(type))) return false;
    }
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    const aPinned = Number(a.pinned);
    const bPinned = Number(b.pinned);
    if (aPinned !== bPinned) return bPinned - aPinned;

    // For deadline sorting, treat null endDate as far future (never ends)
    const FAR_FUTURE = new Date(9999, 11, 31).getTime();
    const aEndTime = a.endDate ? parseLocalDate(a.endDate).getTime() : FAR_FUTURE;
    const bEndTime = b.endDate ? parseLocalDate(b.endDate).getTime() : FAR_FUTURE;

    if (sort === "deadline-asc") return aEndTime - bEndTime;
    if (sort === "deadline-desc") return bEndTime - aEndTime;
    if (sort === "az") return a.name.localeCompare(b.name, locale);
    return b.name.localeCompare(a.name, locale);
  });

  function toggleStatus(s: EventStatus) {
    setStatusFilter((prev) => {
      const next = new Set(prev);
      if (next.has(s)) next.delete(s);
      else next.add(s);
      return next;
    });
  }

  function toggleFormat(f: EventFormat) {
    setFormatFilter((prev) => {
      const next = new Set(prev);
      if (next.has(f)) next.delete(f);
      else next.add(f);
      return next;
    });
  }

  function toggleType(type: ProjectType) {
    setTypeFilter((prev) => {
      const next = new Set(prev);
      if (next.has(type)) next.delete(type);
      else next.add(type);
      return next;
    });
  }

  const statusLabel =
    statusFilter.size === 0
      ? t("status")
      : t("statusWith", {
          values: (["ongoing", "ended", "upcoming"] as EventStatus[])
            .filter((s) => statusFilter.has(s))
            .map((s) => STATUS_LABELS[s])
            .join(", "),
        });
  const formatLabel =
    formatFilter.size === 0
      ? t("format")
      : t("formatWith", {
          values: [...formatFilter].map(formatLabelFn).join(", "),
        });
  const typeLabel =
    typeFilter.size === 0
      ? t("projectType")
      : t("typeWith", {
          values: [...typeFilter].map(projectTypeLabel).join(", "),
        });

  return (
    <main
      id="main"
      tabIndex={-1}
      style={{
        position: "relative",
        background: "var(--background)",
        minHeight: "100vh",
        overflow: "hidden",
      }}
    >
      <style>{`
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        @media (max-width: 700px) { .programs-grid { grid-template-columns: 1fr !important; } }
        input[data-programs-search]::placeholder { opacity: 0.5; }
        input[data-programs-search] { outline: none; }
        .cta-btn .btn-arrow { display: inline-block; transition: transform 0.2s ease; }
        .cta-btn:hover .btn-arrow { transform: translateX(5px); }
        .filter-pill { transition: background 150ms ease, color 150ms ease; }
        .filter-pill:hover { background: rgba(236,55,80,0.08) !important; }
        .filter-pill:active { transform: scale(0.97); }
        .filter-panel { transform-origin: top left; transition: opacity 180ms ease-out, transform 180ms ease-out; }
        .filter-panel[data-open="false"] { opacity: 0; transform: translateY(-8px) scale(0.96); pointer-events: none; }
        .filter-panel[data-open="true"] { opacity: 1; transform: translateY(0) scale(1); pointer-events: auto; }
        .sort-pill { transition: transform 150ms ease, filter 150ms ease, box-shadow 150ms ease; transform-origin: center; }
        .sort-pill[aria-expanded="true"] { transform: translateY(-2px); box-shadow: 0 8px 18px rgba(236,55,80,0.18); }
        .sort-pill:hover { filter: brightness(0.92); }
        .sort-panel { transform-origin: top left; transition: opacity 180ms ease-out, transform 180ms ease-out; }
        .sort-panel[data-open="false"] { opacity: 0; transform: translateY(-8px) scale(0.96); pointer-events: none; }
        .sort-panel[data-open="true"] { opacity: 1; transform: translateY(0) scale(1); pointer-events: auto; }
        .sort-option { transition: background-color 120ms ease, color 120ms ease; }
        .sort-option[data-active="true"] { background: #ec3750; color: #fff; }
        .sort-option:active { transform: scale(0.98); }
        @media (prefers-reduced-motion: reduce) {
          .sort-pill, .sort-panel, .sort-option, .filter-pill, .filter-panel { transition: none !important; }
          .filter-pill:active, .sort-option:active { transform: none !important; }
        }
      `}</style>

      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "linear-gradient(180deg, rgba(236,55,80,0.18) 0%, rgba(236,55,80,0.04) 20%, transparent 40%)",
          pointerEvents: "none",
          zIndex: 0,
        }}
      />
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/assets/bgFade.svg"
        alt=""
        style={{
          position: "absolute",
          top: -12,
          left: -1,
          width: "101%",
          height: "auto",
          opacity: 0.55,
          pointerEvents: "none",
          zIndex: 0,
          transform: "scaleY(-1)",
        }}
      />
      <Image
        ref={magazineBgRef}
        src="/assets/background.webp"
        alt=""
        width={1920}
        height={840}
        sizes="100vw"
        style={{
          position: "absolute",
          top: -60,
          left: 0,
          width: "100%",
          height: "auto",
          transform: "scaleY(-1)",
          opacity: 0.15,
          pointerEvents: "none",
          zIndex: 0,
        }}
      />

      <div style={{ position: "relative", zIndex: 50 }}>
        <Navbar />
      </div>

      <div
        style={{
          position: "relative",
          zIndex: 10,
          paddingTop: "clamp(100px, 14vh, 140px)",
          paddingBottom: 80,
          paddingLeft: "clamp(24px, 14.29%, 220px)",
          paddingRight: "clamp(24px, 14.29%, 220px)",
        }}
      >
        <h1
          style={{
            fontFamily: "var(--font-zarathustra)",
            fontSize: 60,
            fontWeight: "normal",
            lineHeight: 0.92,
            color: "var(--foreground)",
            textAlign: "center",
            margin: "40px 0 16px",
          }}
        >
          {t("title")}
        </h1>
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <p
            style={{
              fontFamily: "var(--font-phantom)",
              fontSize: 20,
              color: "var(--foreground)",
              margin: "0 0 4px",
            }}
          >
            {t("subtitle")}
          </p>
          <p
            style={{
              fontFamily: "var(--font-phantom)",
              fontSize: 20,
              color: "var(--foreground)",
              margin: 0,
            }}
          >
            {t("youtubePrefix")}{" "}
            <a
              href="https://www.youtube.com/@HackClubHQ/videos"
              target="_blank"
              style={{ color: "var(--red-text)", textDecoration: "none" }}
            >
              {t("youtubeLink")}
              <span
                aria-hidden="true"
                style={{ display: "inline-flex", verticalAlign: "middle", marginLeft: 2 }}
              >
                <BtnArrowSvg />
              </span>
            </a>
            {t("youtubeSuffix")}
          </p>
        </div>

        {/* Search */}
        <div
          style={{
            background: "var(--surface)",
            borderRadius: 9999,
            height: 64,
            border: "2.5px solid var(--border)",
            display: "flex",
            alignItems: "center",
            paddingLeft: 28,
            paddingRight: 28,
            marginBottom: 20,
          }}
        >
          <svg
            width="22"
            height="22"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={{ flexShrink: 0, opacity: 0.4, marginRight: 12 }}
          >
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            data-programs-search
            type="text"
            aria-label={t("searchAria")}
            placeholder={t("searchPlaceholder")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              flex: 1,
              background: "transparent",
              border: "none",
              fontFamily: "var(--font-phantom)",
              fontSize: 20,
              color: "var(--foreground)",
            }}
          />
        </div>

        {/* Filters */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 10,
            marginBottom: 32,
            alignItems: "center",
          }}
        >
          {/* Sort dropdown */}
          <div ref={sortRef} style={{ position: "relative", display: "inline-block" }}>
            <button
              onClick={() => (sortOpen ? closeSortPanel() : openSortPanel())}
              className="sort-pill"
              aria-expanded={sortOpen}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                height: 40,
                paddingLeft: 16,
                paddingRight: 16,
                borderRadius: 9999,
                border: "2.5px solid #ec3750",
                background: "#ec3750",
                fontFamily: "var(--font-phantom)",
                fontSize: 20,
                color: "#fff",
                cursor: "pointer",
                whiteSpace: "nowrap",
                outline: "none",
              }}
            >
              {t("sortBy", { label: SORT_LABELS[sort] as string })}
              <Chevron color="#fff" />
            </button>
            {sortMounted && (
              <div
                className="sort-panel"
                data-open={sortVisible}
                style={{
                  position: "absolute",
                  top: "calc(100% + 8px)",
                  left: 0,
                  background: "var(--surface)",
                  border: "3px solid var(--red)",
                  borderRadius: 16,
                  padding: "12px 16px",
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                  zIndex: 100,
                  minWidth: 220,
                  boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
                }}
              >
                {(Object.keys(SORT_LABELS) as SortOption[]).map((k) => (
                  <button
                    key={k}
                    data-active={sort === k}
                    className="sort-option"
                    onClick={() => {
                      setSort(k);
                      closeSortPanel();
                    }}
                    style={{
                      background: sort === k ? "var(--red)" : "transparent",
                      border: "none",
                      borderRadius: 8,
                      padding: "8px 12px",
                      fontFamily: "var(--font-phantom)",
                      fontSize: 20,
                      color: sort === k ? "#fff" : "var(--foreground)",
                      cursor: "pointer",
                      textAlign: "left",
                    }}
                  >
                    {SORT_LABELS[k]}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Status */}
          <PillDropdown
            label={statusLabel}
            active={statusFilter.size > 0}
            onClear={() => setStatusFilter(new Set())}
          >
            {(["ongoing", "ended", "upcoming"] as EventStatus[]).map((s) => (
              <CheckItem
                key={s}
                label={STATUS_LABELS[s]}
                checked={statusFilter.has(s)}
                onToggle={() => toggleStatus(s)}
              />
            ))}
          </PillDropdown>

          {/* Format */}
          <PillDropdown
            label={formatLabel}
            active={formatFilter.size > 0}
            onClear={() => setFormatFilter(new Set())}
          >
            {FORMAT_OPTIONS.map((f) => (
              <CheckItem
                key={f}
                label={formatLabelFn(f)}
                checked={formatFilter.has(f)}
                onToggle={() => toggleFormat(f)}
              />
            ))}
          </PillDropdown>

          {/* Project type */}
          <PillDropdown
            label={typeLabel}
            active={typeFilter.size > 0}
            onClear={() => setTypeFilter(new Set())}
          >
            {PROJECT_TYPE_OPTIONS.map((type) => (
              <CheckItem
                key={type}
                label={projectTypeLabel(type)}
                checked={typeFilter.has(type)}
                onToggle={() => toggleType(type)}
              />
            ))}
          </PillDropdown>
        </div>

        {error && (
          <p
            style={{
              fontFamily: "var(--font-phantom)",
              color: "var(--red-text)",
              fontSize: 16,
              textAlign: "center",
              marginBottom: 32,
            }}
          >
            {error}
          </p>
        )}

        <div
          className="programs-grid"
          style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 28 }}
        >
          {events === null
            ? Array.from({ length: 4 }).map((_, i) => <CardSkeleton key={i} />)
            : sorted.map((p) => <ProgramCard key={p.id} event={p} />)}
        </div>

        {events !== null && sorted.length === 0 && (
          <p
            style={{
              fontFamily: "var(--font-phantom)",
              fontSize: 20,
              color: "var(--foreground)",
              opacity: 0.5,
              textAlign: "center",
              marginTop: 40,
            }}
          >
            {search ? t("emptyMatching", { search }) : t("empty")}
          </p>
        )}

        {/* Footer */}
        <div
          style={{
            marginTop: 80,
            display: "flex",
            flexDirection: "column",
            gap: 8,
            textAlign: "center",
          }}
        >
          <p
            style={{
              fontFamily: "var(--font-phantom)",
              fontSize: 20,
              color: "var(--foreground)",
              opacity: 0.55,
              margin: 0,
            }}
          >
            {t("footerSlackBefore")}{" "}
            <a
              href="https://slack.hackclub.com"
              target="_blank"
              rel="noopener noreferrer"
              style={{ color: "var(--red-text)", textDecoration: "none" }}
            >
              {t("footerSlackLink")}
            </a>
            {t("footerSlackAfter")}
          </p>
          <p
            style={{
              fontFamily: "var(--font-phantom)",
              fontSize: 20,
              color: "var(--foreground)",
              opacity: 0.55,
              margin: 0,
            }}
          >
            <Link
              href="/programs/edit"
              style={{ color: "var(--red-text)", textDecoration: "none" }}
            >
              Event editor
            </Link>
            {" · "}
            <NextLink
              href="/api/v1/docs"
              prefetch={false}
              style={{ color: "var(--red-text)", textDecoration: "none" }}
            >
              Events API
            </NextLink>
            {" · "}
            <NextLink
              href="/api/v1/events/rss"
              prefetch={false}
              style={{ color: "var(--red-text)", textDecoration: "none" }}
            >
              RSS feed
            </NextLink>
          </p>
        </div>
      </div>
      <Footer />
    </main>
  );
}
